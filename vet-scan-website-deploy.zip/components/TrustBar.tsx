export default function TrustBar(){
  return (
    <div className="section pt-0">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 items-center opacity-70">
        <div className="h-10 bg-white border border-gray-100 rounded-xl flex items-center justify-center text-sm">Clinic Logo</div>
        <div className="h-10 bg-white border border-gray-100 rounded-xl flex items-center justify-center text-sm">Clinic Logo</div>
        <div className="h-10 bg-white border border-gray-100 rounded-xl flex items-center justify-center text-sm">Clinic Logo</div>
        <div className="h-10 bg-white border border-gray-100 rounded-xl flex items-center justify-center text-sm">Clinic Logo</div>
      </div>
    </div>
  )
}
